# TSN_JAVA_POI_XLS
Пример работы с MS EXCEL на Java в NetBeans 
![srcreenshot](screenshot1.png)

![srcreenshot](screenshot2.png)
